package com.freecam;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Marker;

/**
 * Client-side freecam.
 *
 * How it stays invisible to the server:
 *  - The real player's input is swapped for an empty one, so it never moves, jumps or sneaks.
 *  - Mouse look is redirected to the camera (see EntityMixin), so the player never rotates.
 *  - Attack / use / pick / drop / swap-hands are suppressed, so no interaction packets are sent.
 *  - The camera is a local-only Marker entity that is never added to the world.
 * The server only ever sees your real player standing still.
 */
public final class Freecam {
    private static final double BASE_SPEED_STEP = 0.1;
    private static final double SPRINT_MULTIPLIER = 3.0;

    private static boolean active;
    private static Marker camera;
    private static ClientInput savedInput;
    private static LocalPlayer trackedPlayer;
    private static double speed = 0.5; // blocks per tick

    private Freecam() {}

    public static boolean isActive() {
        return active;
    }

    public static void startTick(Minecraft mc) {
        while (FreecamClient.TOGGLE.consumeClick()) {
            if (active) disable(mc); else enable(mc);
        }
        while (FreecamClient.FASTER.consumeClick()) changeSpeed(mc, BASE_SPEED_STEP);
        while (FreecamClient.SLOWER.consumeClick()) changeSpeed(mc, -BASE_SPEED_STEP);

        if (active) tick(mc);
    }

    private static void changeSpeed(Minecraft mc, double delta) {
        speed = Mth.clamp(speed + delta, 0.1, 5.0);
        if (active && mc.player != null) {
            mc.player.displayClientMessage(
                    Component.literal(String.format("Freecam speed: %.1f", speed * 20.0) + " blocks/s"), true);
        }
    }

    public static void enable(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || active) return;

        trackedPlayer = p;
        savedInput = p.input;
        p.input = new ClientInput() {};

        camera = new Marker(EntityType.MARKER, mc.level);
        camera.setPos(p.getX(), p.getEyeY(), p.getZ());
        camera.setYRot(p.getYRot());
        camera.setXRot(p.getXRot());
        camera.setOldPosAndRot();

        mc.setCameraEntity(camera);
        active = true;
        p.displayClientMessage(Component.literal("Freecam enabled"), true);
    }

    public static void disable(Minecraft mc) {
        if (!active) return;
        LocalPlayer p = mc.player;
        if (p != null && p == trackedPlayer && savedInput != null) {
            p.input = savedInput;
        }
        if (p != null) {
            mc.setCameraEntity(p);
            p.displayClientMessage(Component.literal("Freecam disabled"), true);
        }
        reset();
    }

    /** Clears state without touching the player (used on disconnect / respawn). */
    public static void reset() {
        active = false;
        camera = null;
        savedInput = null;
        trackedPlayer = null;
    }

    private static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        // Bail out safely if the player object changed (respawn, dimension change) or got hurt.
        if (p == null || mc.level == null || p != trackedPlayer || p.hurtTime > 0 || p.isDeadOrDying()) {
            if (p != null && p == trackedPlayer) {
                disable(mc);
            } else {
                if (p != null) mc.setCameraEntity(p);
                reset();
            }
            return;
        }

        Options o = mc.options;

        // Swallow anything that would make the real player send interaction packets.
        KeyMapping[] blocked = {o.keyAttack, o.keyUse, o.keyPickItem, o.keyDrop, o.keySwapOffhand};
        for (KeyMapping k : blocked) {
            k.setDown(false);
            while (k.consumeClick()) { /* discard */ }
        }

        camera.setOldPosAndRot();
        if (mc.screen != null) return;

        double yaw = Math.toRadians(camera.getYRot());
        double pitch = Math.toRadians(camera.getXRot());

        // Forward follows where you look (including pitch); strafe is horizontal.
        double fx = -Math.sin(yaw) * Math.cos(pitch);
        double fy = -Math.sin(pitch);
        double fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw);
        double rz = -Math.sin(yaw);

        double f = (o.keyUp.isDown() ? 1 : 0) - (o.keyDown.isDown() ? 1 : 0);
        double s = (o.keyRight.isDown() ? 1 : 0) - (o.keyLeft.isDown() ? 1 : 0);
        double v = (o.keyJump.isDown() ? 1 : 0) - (o.keyShift.isDown() ? 1 : 0);

        double dx = fx * f + rx * s;
        double dy = fy * f + v;
        double dz = fz * f + rz * s;

        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len > 1.0E-6) {
            double m = speed * (o.keySprint.isDown() ? SPRINT_MULTIPLIER : 1.0) / len;
            camera.setPos(camera.getX() + dx * m, camera.getY() + dy * m, camera.getZ() + dz * m);
        }
    }

    /** Called from EntityMixin in place of the player's own mouse look. */
    public static void turn(double yRot, double xRot) {
        if (camera == null) return;
        float oldYaw = camera.getYRot();
        float oldPitch = camera.getXRot();
        float newYaw = oldYaw + (float) yRot * 0.15F;
        float newPitch = Mth.clamp(oldPitch + (float) xRot * 0.15F, -90.0F, 90.0F);
        camera.setYRot(newYaw);
        camera.setXRot(newPitch);
        // Keep render interpolation smooth, same as vanilla Entity.turn.
        camera.yRotO += newYaw - oldYaw;
        camera.xRotO += newPitch - oldPitch;
    }
}
