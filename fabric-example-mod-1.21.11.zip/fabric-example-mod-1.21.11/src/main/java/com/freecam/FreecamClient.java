package com.freecam;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public class FreecamClient implements ClientModInitializer {
    public static KeyMapping TOGGLE;
    public static KeyMapping FASTER;
    public static KeyMapping SLOWER;

    @Override
    public void onInitializeClient() {
        TOGGLE = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.freecam.toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, KeyMapping.Category.MISC));
        FASTER = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.freecam.faster", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_EQUAL, KeyMapping.Category.MISC));
        SLOWER = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.freecam.slower", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_MINUS, KeyMapping.Category.MISC));

        ClientTickEvents.START_CLIENT_TICK.register(Freecam::startTick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> Freecam.reset());
    }
}
