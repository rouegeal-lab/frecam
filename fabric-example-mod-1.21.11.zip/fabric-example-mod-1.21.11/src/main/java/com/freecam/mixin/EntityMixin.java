package com.freecam.mixin;

import com.freecam.Freecam;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Redirects mouse look to the free camera while freecam is active, so the real
 * player's rotation never changes (and no rotation packets reach the server).
 */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "turn(DD)V", at = @At("HEAD"), cancellable = true)
    private void freecam$turn(double yRot, double xRot, CallbackInfo ci) {
        if (Freecam.isActive() && (Object) this instanceof LocalPlayer) {
            Freecam.turn(yRot, xRot);
            ci.cancel();
        }
    }
}
